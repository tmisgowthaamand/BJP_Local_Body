# Phase 4 — Booth President

## Read previous handoff first
Before starting, read `whatsapp_prompts/handoffs/phase_3_handoff.md`.
If Phase 3 status is BLOCKED, do not proceed — report the blocker.

## Project
BJP Nalam Thittam WhatsApp Automation — building on Phase 1–3.
Backend working dir: `production bjp repo/backend/`
Phase 3 built: full service flow with 5 tiles.
waServiceCatalog.js currently has 5 tiles — add 6th (Booth President) here.
Jurisdiction service exports:
  getAssemblyMetadata() → array of { assemblyNo, assemblyName, district, ... }
  getBoothCredentialsForAssembly(assemblyNo) → { boothLogins: [{ boothNo }] }

## Deliverable
6th service tile: "Be a Booth President"
- If user has an existing BoothPresidentRequest → show status screen
- If not → show current booth + option to choose another
- "Another Booth" path: District dropdown → Assembly dropdown → Booth dropdown → Confirm
- On confirm → create BoothPresidentRequest → loop back to service menu

## Changes

### 1. Extend backend/services/waServiceCatalog.js
Add 6th tile to SERVICE_TILES:
  {
    id: 'booth_president',
    title_en: 'Be a Booth President', title_ta: 'துறை தலைவராக விண்ணப்பிக்கவும்',
    desc_en: 'Apply to lead your booth', desc_ta: 'உங்கள் துறையை வழிநடத்த விண்ணப்பிக்கவும்',
    icon_key: 'wa_svc_booth_president'
  }

### 2. Extend backend/services/waFlowJson.js (add Booth President screens)

getBoothStatusScreen(request, lang):
  request = BoothPresidentRequest document
  Returns BOOTH_STATUS screen:
    District: request.district
    Assembly: request.assemblyName
    Booth: request.boothNo
    Status: request.status (Pending / Approved / Rejected)
    Applied: request.appliedAt formatted DD/MM/YYYY
    If status === 'Rejected' and request.rejectionReason: show Reason field
  Footer: Back to menu

getBoothCurrentScreen(user, lang):
  Returns BOOTH_CURRENT screen:
    TextBody: "Your registered booth details:"
    District: user.district
    Assembly: user.assemblyName
    Booth: user.boothNo
    RadioButtonsGroup with 2 options:
      { id: 'my_booth', label: lang==='en' ? 'Confirm this booth' : 'இந்த துறையை உறுதி செய்க' }
      { id: 'other_booth', label: lang==='en' ? 'Choose another booth' : 'வேறு துறை தேர்வு' }
  Footer: Continue

getBoothDistrictScreen(districts, lang):
  districts = array of district name strings (sorted alphabetically)
  Returns BOOTH_DISTRICT screen:
    Dropdown (name: 'selected_district', label: lang==='en' ? 'Select District' : 'மாவட்டம் தேர்வு')
    Options: districts.map(d => ({ id: d, label: d }))
  Footer: Next

getBoothAssemblyScreen(assemblies, selectedDistrict, lang):
  assemblies = array of { assemblyNo, assemblyName } for the selected district
  Returns BOOTH_ASSEMBLY screen:
    TextBody showing selected district
    Dropdown (name: 'selected_assembly', label: lang==='en' ? 'Select Assembly' : 'தொகுதி தேர்வு')
    Options: assemblies.map(a => ({ id: a.assemblyName, label: a.assemblyName }))
  Footer: Next

getBoothBoothScreen(booths, selectedAssembly, lang):
  booths = array of boothNo strings
  Returns BOOTH_BOOTH screen:
    TextBody showing selected district + assembly
    Dropdown (name: 'selected_booth', label: lang==='en' ? 'Select Booth' : 'துறை தேர்வு')
    Options: booths.map(b => ({ id: b, label: `Booth ${b}` }))
  Footer: Next

getBoothConfirmScreen(selection, lang):
  selection = { district, assemblyName, boothNo }
  Returns BOOTH_CONFIRM screen:
    TextBody: "Confirm your booth president application:"
    District: selection.district
    Assembly: selection.assemblyName
    Booth: selection.boothNo
  Footer: Confirm + Back

### 3. Extend backend/routes/whatsappFlow.js (add Booth President screen handlers)

screen === 'BOOTH_PRESIDENT' (entry — route from MENU selection):
  Check for existing BoothPresidentRequest: 
    const request = await BoothPresidentRequest.findOne({ userId: user._id })
  If exists: return getBoothStatusScreen(request, lang)
  If not: return getBoothCurrentScreen(user, lang)

screen === 'BOOTH_CURRENT' (data_exchange, user submitted choice):
  If data.choice === 'my_booth':
    Return getBoothConfirmScreen({ district: user.district, assemblyName: user.assemblyName, boothNo: user.boothNo }, lang)
  If data.choice === 'other_booth':
    const allAssemblies = await getAssemblyMetadata()
    const districts = [...new Set(allAssemblies.map(a => a.district))].sort()
    Return getBoothDistrictScreen(districts, lang)

screen === 'BOOTH_DISTRICT' (data_exchange):
  selectedDistrict = data.selected_district
  const allAssemblies = await getAssemblyMetadata()
  const filtered = allAssemblies
    .filter(a => a.district === selectedDistrict)
    .map(a => ({ assemblyNo: a.assemblyNo, assemblyName: a.assemblyName }))
  Return getBoothAssemblyScreen(filtered, selectedDistrict, lang)

screen === 'BOOTH_ASSEMBLY' (data_exchange):
  selectedAssemblyName = data.selected_assembly
  const allAssemblies = await getAssemblyMetadata()
  const match = allAssemblies.find(a => a.assemblyName === selectedAssemblyName)
  if (!match): return error screen
  const boothData = await getBoothCredentialsForAssembly(match.assemblyNo)
  const booths = boothData?.boothLogins?.map(b => b.boothNo) || []
  Return getBoothBoothScreen(booths, selectedAssemblyName, lang)

screen === 'BOOTH_BOOTH' (data_exchange):
  selectedBoothNo = data.selected_booth
  selectedDistrict = data.selected_district (passed through in flow data)
  selectedAssemblyName = data.selected_assembly (passed through)
  Return getBoothConfirmScreen({ district: selectedDistrict, assemblyName: selectedAssemblyName, boothNo: selectedBoothNo }, lang)

screen === 'BOOTH_CONFIRM' (Confirm action):
  Call handleFlowComplete(phone, 'BOOTH_PRESIDENT', {
    district: data.district,
    assemblyName: data.assemblyName,
    boothNo: data.boothNo,
    isCustomBooth: data.is_custom_booth (boolean passed through)
  })
  Return { screen:'SUCCESS', data:{} }

### 4. Extend backend/services/whatsappChatbot.js
Add handleFlowComplete for flowType === 'BOOTH_PRESIDENT':
  const { district, assemblyName, boothNo, isCustomBooth } = payload
  const user = await User.findOne({ mobile: phone })

  // Duplicate check — any status (pending/approved/rejected)
  const existing = await BoothPresidentRequest.findOne({ userId: user._id })
  if (existing) {
    // Do not create duplicate — just re-send service CTA
  } else {
    await BoothPresidentRequest.create({
      userId: user._id,
      voterName: user.voterName,
      epicNo: user.epicNo,
      mobile: user.mobile,
      gender: user.gender || 'Unspecified',
      district: district,
      assemblyName: assemblyName,
      assemblyNo: '', // will be blank if custom, ok
      boothNo: boothNo,
      isCustomBooth: isCustomBooth || false,
      originalDistrict: user.district,
      originalAssembly: user.assemblyName,
      originalBoothNo: user.boothNo,
      status: 'Pending'
    })
  }

  // Re-send Choose Service CTA
  const contact = await WhatsAppContact.findOne({ phone })
  const lang = contact?.language || 'en'
  await sendFlowMessage(phone, '',
    lang==='en' ? 'Request submitted!' : 'கோரிக்கை சமர்ப்பிக்கப்பட்டது!',
    '', process.env.WHATSAPP_SERVICE_FLOW_ID || 'PENDING',
    lang==='en' ? 'Choose Service' : 'சேவை தேர்வு',
    'MENU', { phone })

## Constraints
- Duplicate BoothPresidentRequest check: if ANY request exists for this userId (any status), 
  show BOOTH_STATUS instead of creating a new one
- isCustomBooth = false when user confirms their own registered booth (my_booth choice)
- isCustomBooth = true when user goes through district/assembly/booth dropdowns
- originalDistrict/Assembly/BoothNo always saved from User record, regardless of custom selection
- District/Assembly/Booth data comes from jurisdictionService — never hardcoded
- Pass district and assembly through successive screen data payloads so BOOTH_CONFIRM
  has all 3 values (district, assemblyName, boothNo) available

## Output — write to handoffs/phase_4_handoff.md

Create `whatsapp_prompts/handoffs/phase_4_handoff.md`:

```
# Phase 4 Handoff — Booth President

## Files Modified
- [list]

## Verification
waServiceCatalog.js updated to 6 tiles: [yes/no]
BOOTH_STATUS screen (existing request): [yes/no]
BOOTH_CURRENT screen (my_booth / other_booth choice): [yes/no]
BOOTH_DISTRICT dropdown (all TN districts): [yes/no]
BOOTH_ASSEMBLY dropdown (filtered by district): [yes/no]
BOOTH_BOOTH dropdown (filtered by assembly via jurisdictionService): [yes/no]
BOOTH_CONFIRM screen: [yes/no]
BoothPresidentRequest creation: [yes/no]
Duplicate request blocked (any status): [yes/no]
isCustomBooth flag set correctly: [yes/no]
originalDistrict/Assembly/BoothNo saved from User: [yes/no]
Loops back to service menu after confirm: [yes/no]

## Notes
[Anything Phase 5 should know]

## Blockers for Phase 5
[list / none]

## Status
[READY FOR PHASE 5 / BLOCKED — reason]
```

Then update `whatsapp_prompts/progress.md` — Phase 4 status.
