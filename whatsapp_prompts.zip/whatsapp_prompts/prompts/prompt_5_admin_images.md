# Phase 5 — Admin Flow Images Page

## Read previous handoff first
Before starting, read `whatsapp_prompts/handoffs/phase_4_handoff.md`.
If Phase 4 status is BLOCKED, do not proceed — report the blocker.

## Project
BJP Nalam Thittam WhatsApp Automation — building on Phase 1–4.
Backend working dir: `production bjp repo/backend/`
Frontend working dir: `production bjp repo/frontend/src/`
Frontend stack: React + Vite. Existing admin: SuperAdminDashboard.jsx, AdminSidebar.jsx
Cloudinary already wired in: backend/services/cloudinaryService.js
Auth middleware: backend/middleware/authMiddleware.js (has protectAdmin for role checks)

## Deliverable
Super Admin can upload and manage all WhatsApp flow images from the admin panel.
The flow endpoint picks up new images within 10 minutes via cache.

## Backend

### 1. backend/models/FlowImage.js
Mongoose schema:
  key: String, required, unique, trim (e.g. 'wa_language_header')
  url: String, required (Cloudinary secure_url)
  publicId: String, default: '' (Cloudinary public_id for deletion)
  resourceType: String, default: 'image'
  updatedAt: Date, default: Date.now

Export mongoose.model('FlowImage', schema)

### 2. backend/services/flowImages.js
In-memory cache: const imageCache = { data: null, expiresAt: 0 }
TTL: 10 minutes (600000ms)

getFlowImage(key):
  const all = await getAllFlowImages()
  return all[key] || null

getAllFlowImages():
  If cache valid (Date.now() < expiresAt): return cache.data
  const docs = await FlowImage.find({})
  Build map: { [doc.key]: doc.url }
  Set cache.data = map, cache.expiresAt = Date.now() + 600000
  return map

upsertFlowImage(key, url, publicId):
  await FlowImage.findOneAndUpdate({ key }, { url, publicId, updatedAt: new Date() }, 
    { upsert: true, new: true })
  bustImageCache()

deleteFlowImage(key):
  await FlowImage.deleteOne({ key })
  bustImageCache()

bustImageCache():
  imageCache.data = null
  imageCache.expiresAt = 0
  Also call bustCache(url) from imageBase64.js for the old URL if known

Export: getFlowImage, getAllFlowImages, upsertFlowImage, deleteFlowImage, bustImageCache

### 3. backend/routes/flowImages.js
All routes: use protectAdmin middleware, check req.admin.role === 'SUPER_ADMIN'.

GLOBAL SLOTS:
GET /api/admin/flow-images
  Returns: { slots: ALL_SLOT_KEYS.map(key => ({ key, label: SLOT_LABELS[key], url: currentUrl || null })) }

ALL_SLOT_KEYS (define as constant at top of file):
['wa_language_header','wa_register_header','wa_register_banner',
 'wa_choose_service_banner','wa_choose_service_header','wa_confirm_header',
 'wa_member_default_icon','wa_svc_my_profile','wa_svc_my_schemes',
 'wa_svc_apply_schemes','wa_svc_referral','wa_svc_members','wa_svc_booth_president']

SLOT_LABELS (human-readable names for the UI):
  wa_language_header: 'Language Screen Header',
  wa_register_header: 'Register CTA Header',
  wa_register_banner: 'Register Flow Banner',
  wa_choose_service_banner: 'Choose Service Banner',
  wa_choose_service_header: 'Choose Service Header',
  wa_confirm_header: 'Confirmation Message Header',
  wa_member_default_icon: 'Member Default Icon',
  wa_svc_my_profile: 'My Profile Icon',
  wa_svc_my_schemes: 'My Schemes Icon',
  wa_svc_apply_schemes: 'Apply Schemes Icon',
  wa_svc_referral: 'My Referral Icon',
  wa_svc_members: 'My Members Icon',
  wa_svc_booth_president: 'Booth President Icon'

POST /api/admin/flow-images/:key
  Accepts multipart/form-data with field 'image'
  Upload to Cloudinary using cloudinaryService, folder: 'bjp_wa_flow_images'
  await upsertFlowImage(key, result.secure_url, result.public_id)
  Return: { success: true, url: result.secure_url }

DELETE /api/admin/flow-images/:key
  Get existing FlowImage for key
  If exists and publicId: delete from Cloudinary
  await deleteFlowImage(key)
  Return: { success: true }

PER-SCHEME IMAGES:
GET /api/admin/flow-images/schemes
  Scheme.find({ active: true }).sort({ order:1, id:1 }).select('id name waLogo waBanner')
  Return: { schemes: [...] }

POST /api/admin/flow-images/schemes/:schemeId/logo
  Accepts multipart/form-data with field 'image'
  Upload to Cloudinary, folder: 'bjp_wa_scheme_images'
  Scheme.findOneAndUpdate({ id: Number(schemeId) }, { waLogo: result.secure_url })
  Bust imageBase64 cache for old URL
  Return: { success: true, url: result.secure_url }

POST /api/admin/flow-images/schemes/:schemeId/banner
  Same as logo but updates waBanner

Mount in server.js:
  const flowImageRoutes = require('./routes/flowImages')
  app.use('/api/admin', flowImageRoutes)

### 4. Extend backend/services/imageBase64.js
Export bustCache(url) — already defined in Phase 2.
Confirm it's exported and accessible.

## Frontend

### 5. frontend/src/components/FlowImagesView.jsx
New React component. Follow the same patterns as SchemesManagementView.jsx.

Layout:
Section 1 — "Flow / WhatsApp Images" (global slots)
  Grid of 13 cards. Each card:
    - Slot label (human readable)
    - Current image preview (if url exists — <img src={url} style={{maxHeight:80}} />)
    - "Upload" button → triggers file input → POST to /api/admin/flow-images/:key
    - "Remove" button (only if image exists) → DELETE /api/admin/flow-images/:key
    - Show spinner during upload, success/error toast after

Section 2 — "Scheme WhatsApp Images"
  Table with columns: Scheme Name | Logo (upload/preview) | Banner (upload/preview)
  Each row fetched from GET /api/admin/flow-images/schemes
  Upload buttons POST to /api/admin/flow-images/schemes/:schemeId/logo (or /banner)
  Show current image as small thumbnail if url exists

Use existing API utility (frontend/src/utils/api.js or src/api/index.js) for requests.
Include admin auth token in headers (same pattern as other admin components).

### 6. Modify frontend/src/components/AdminSidebar.jsx
Add "Flow Images" menu item:
  Only visible when admin.role === 'SUPER_ADMIN'
  Position: after "Schemes" in the sidebar
  On click: set active view to 'flow_images' (same pattern as other views)

### 7. Modify frontend/src/pages/admin/SuperAdminDashboard.jsx
Import FlowImagesView
Add case for 'flow_images' view in the render switch/conditional

## Constraints
- Only SUPER_ADMIN role can access all /api/admin/flow-images/* routes
- Uploaded images must go to the correct Cloudinary folders as specified
- When a scheme's waLogo or waBanner is updated, bust imageBase64 cache for old URL
- Frontend upload: disable the Upload button while upload is in progress
- Do NOT break any existing admin views or sidebar items

## Output — write to handoffs/phase_5_handoff.md

Create `whatsapp_prompts/handoffs/phase_5_handoff.md`:

```
# Phase 5 Handoff — Admin Flow Images Page

## Files Created
- [list]

## Files Modified
- [list]

## Verification
FlowImage model: [yes/no]
flowImages service (getAllFlowImages, upsertFlowImage, deleteFlowImage, bustImageCache): [yes/no]
10-minute cache: [yes/no]
bustCache export from imageBase64.js: [yes/no]
flowImages routes mounted (SUPER_ADMIN protected): [yes/no]
Global slot endpoints (GET, POST :key, DELETE :key): [yes/no]
Per-scheme endpoints (GET schemes, POST logo, POST banner): [yes/no]
FlowImagesView.jsx component built: [yes/no]
AdminSidebar Flow Images item (SUPER_ADMIN only): [yes/no]
SuperAdminDashboard wired: [yes/no]

## Notes
[Anything Phase 6 should know]

## Blockers for Phase 6
[list / none]

## Status
[READY FOR PHASE 6 / BLOCKED — reason]
```

Then update `whatsapp_prompts/progress.md` — Phase 5 status.
