# Phase 0 — Verify Meta Credentials & Environment

## No previous handoff required — this is the first phase.

## Project
BJP Nalam Thittam WhatsApp Automation
Backend working dir: `production bjp repo/backend/`
Stack: Node.js + Express + MongoDB

## Your Task
Verify that all Meta API credentials and environment variables are present and functional.
Do NOT build anything in this phase. Only verify and report.

## Checks to perform

### 1. Check backend/.env for these keys
- META_ACCESS_TOKEN — must be present and non-empty
- META_APP_ID — expected value: 1509484690547937
- META_APP_SECRET — must be present and non-empty
- META_PHONE_NUMBER_ID — expected value: 1237240656129241
- META_WABA_ID — expected value: 1333149808374304
- META_GRAPH_VERSION — expected value: v22.0
- META_VERIFY_TOKEN — expected value: bjp_nalam_whatsapp_2026
- CLOUDINARY_CLOUD_NAME — must be present
- CLOUDINARY_API_KEY — must be present
- CLOUDINARY_API_SECRET — must be present
- MONGO_APP_URL — must be present
- JWT_SECRET — must be present and >= 32 characters

### 2. Validate META_ACCESS_TOKEN is live
Call: GET https://graph.facebook.com/v22.0/me?access_token={META_ACCESS_TOKEN}
Expected: 200 response with an id field.
Report: valid / expired / invalid

### 3. Check if webhook route already exists
Search in backend/server.js and backend/routes/ for any existing:
- /api/whatsapp/webhook route
- /api/whatsapp/flow route
Report: exists / not found

### 4. Check if any WhatsApp-related files already exist
Search backend/ for: whatsappWebhook.js, whatsappFlow.js, metaCloud.js, 
whatsappChatbot.js, waFlowJson.js, WhatsAppContact.js
Report each: exists / not found

### 5. Check package.json for existing dependencies
Look in backend/package.json for: node-forge, sharp, axios
Report each: present / missing

### 6. Check Node.js version
Run: node --version
Report the version.

## Output — write to handoffs/phase_0_handoff.md

Create the file `whatsapp_prompts/handoffs/phase_0_handoff.md` with this exact structure:

```
# Phase 0 Handoff — Verify Meta Credentials

## Environment Variables
META_ACCESS_TOKEN: [valid / expired / invalid / missing]
META_APP_ID: [confirmed 1509484690547937 / mismatch: actual value / missing]
META_APP_SECRET: [present / missing]
META_PHONE_NUMBER_ID: [confirmed 1237240656129241 / mismatch / missing]
META_WABA_ID: [confirmed 1333149808374304 / mismatch / missing]
META_GRAPH_VERSION: [confirmed v22.0 / mismatch / missing]
META_VERIFY_TOKEN: [confirmed bjp_nalam_whatsapp_2026 / different value / missing]
CLOUDINARY_*: [all present / missing: list what's missing]
MONGO_APP_URL: [present / missing]
JWT_SECRET: [present and strong / weak / missing]

## Token Validation
META_ACCESS_TOKEN live check: [pass — response id: xxx / fail — reason]

## Existing WhatsApp Files
whatsappWebhook.js: [exists at path / not found]
whatsappFlow.js: [exists at path / not found]
metaCloud.js: [exists at path / not found]
whatsappChatbot.js: [exists at path / not found]
waFlowJson.js: [exists at path / not found]
WhatsAppContact.js: [exists at path / not found]

## Webhook Routes in server.js
/api/whatsapp/webhook: [already mounted / not found]
/api/whatsapp/flow: [already mounted / not found]

## Dependencies
node-forge: [present / missing — needs install]
sharp: [present / missing — needs install]
axios: [present / missing — needs install]

## Node.js Version
node: [version]

## Blockers for Phase 1
[List any blockers — missing critical env vars, expired token, etc. / none]

## Overall Status
[READY FOR PHASE 1 / BLOCKED — reason]
```

Then update `whatsapp_prompts/progress.md`:
- Change Phase 0 status to ✅ Complete (or ❌ Blocked)
- Set Last updated and Current phase fields
