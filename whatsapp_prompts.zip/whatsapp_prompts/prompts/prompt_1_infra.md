# Phase 1 — Infrastructure

## Read previous handoff first
Before starting, read `whatsapp_prompts/handoffs/phase_0_handoff.md`.
If Phase 0 status is BLOCKED, do not proceed — report the blocker.

## Project
BJP Nalam Thittam WhatsApp Automation
Backend working dir: `production bjp repo/backend/`
Stack: Node.js + Express + MongoDB (Mongoose)
Existing services: voterSearchService.js (findVoterByEpic), jurisdictionService.js,
cloudinaryService.js
Existing models: User, Scheme, SchemeApplication, BoothPresidentRequest

## Deliverable
User sends "hi" → bot replies with image header + body + 2 buttons (English / தமிழ்)
→ user picks language → bot replies with image header + body + Register flow button (CTA).

## Files to create

### 1. backend/models/WhatsAppContact.js
Mongoose schema with fields:
- phone: String, required, unique (stored as 10-digit, e.g. 9876543210)
- language: String, enum: ['en', 'ta'], default: 'en'
- step: String, default: 'INIT'
  (values used: INIT, LANG_SELECT, REGISTER_CTA, SERVICE_CTA)
- lastVoterSnapshot: Object, default: {}
  (stores voter data during registration session — ephemeral, not exposed to users)
- pendingBoothSelection: Object, default: {}
- updatedAt: Date, default: Date.now

Export as mongoose.model('WhatsAppContact', schema)

### 2. backend/services/metaCloud.js
All functions call Meta Graph API v22.0.
Use axios (already in package.json).
Base URL: https://graph.facebook.com/v22.0
Auth: ?access_token=${process.env.META_ACCESS_TOKEN} on all calls.
All functions: log errors but return null on failure (never throw).

Functions to build:

sendText(to, text)
  POST /{META_PHONE_NUMBER_ID}/messages
  body: { messaging_product:'whatsapp', to, type:'text', text:{ body: text } }

sendInteractiveButtons(to, imageUrl, bodyText, buttons)
  buttons = array of { id, title }
  POST /{META_PHONE_NUMBER_ID}/messages
  body: {
    messaging_product:'whatsapp', to, type:'interactive',
    interactive: {
      type: 'button',
      header: { type:'image', image:{ link: imageUrl } },
      body: { text: bodyText },
      action: { buttons: buttons.map(b => ({ type:'reply', reply:{ id:b.id, title:b.title } })) }
    }
  }

sendFlowMessage(to, imageUrl, bodyText, footerText, flowId, flowCta, screenId, data)
  POST /{META_PHONE_NUMBER_ID}/messages
  body: {
    messaging_product:'whatsapp', to, type:'interactive',
    interactive: {
      type:'flow',
      header: { type:'image', image:{ link: imageUrl } },
      body: { text: bodyText },
      footer: { text: footerText },
      action: {
        name:'flow',
        parameters: {
          flow_message_version:'3',
          flow_token: to,
          flow_id: flowId,
          flow_cta: flowCta,
          flow_action:'navigate',
          flow_action_payload: { screen: screenId, data: data || {} }
        }
      }
    }
  }

downloadMedia(mediaId) → returns buffer
  GET /{mediaId} → get url from response
  Then GET url with Authorization: Bearer {META_ACCESS_TOKEN} → return buffer

### 3. backend/routes/whatsappWebhook.js
GET /api/whatsapp/webhook
  Check query params: hub.mode === 'subscribe' AND hub.verify_token === META_VERIFY_TOKEN
  If match: return res.send(req.query['hub.challenge'])
  Else: return res.sendStatus(403)

POST /api/whatsapp/webhook
  1. Verify X-Hub-Signature-256 header using HMAC-SHA256 of req.rawBody with META_APP_SECRET
     If missing or invalid: return res.sendStatus(403)
  2. Parse body for messages:
     const entries = req.body.entry || []
     For each entry → changes → value → messages → first message
  3. For each message: extract { from, type, text, button_reply, interactive }
     Normalize phone: strip leading '91' from 'from' field to get 10-digit
     Call handleInbound(message, from_normalized) from whatsappChatbot.js
  4. Always return res.sendStatus(200) immediately (before processing) 
     to acknowledge receipt to Meta within 5 seconds

### 4. backend/services/whatsappChatbot.js
handleInbound(message, phone):
  phone is already 10-digit normalized.

  Case 1 — text message "hi" or "hello" (case insensitive):
    Upsert WhatsAppContact: { phone, step: 'LANG_SELECT' }
    Get wa_language_header image URL from FlowImage (if model exists) or use placeholder
    Call sendInteractiveButtons(phone, imageUrl, bodyText, [
      { id:'lang_en', title:'English' },
      { id:'lang_ta', title:'தமிழ்' }
    ])
    Note: FlowImage model is built in Phase 5. For now, use a hardcoded placeholder URL
    or read from process.env.WA_PLACEHOLDER_IMAGE_URL if set.

  Case 2 — button_reply.id === 'lang_en' or 'lang_ta':
    lang = button_reply.id === 'lang_en' ? 'en' : 'ta'
    Update WhatsAppContact: { language: lang, step: 'REGISTER_CTA' }
    Get wa_register_header image URL (placeholder if not yet in DB)
    bodyText = lang === 'en' 
      ? 'Welcome to BJP Nalam Thittam. Register to access government schemes.'
      : 'BJP நலம் திட்டத்திற்கு வரவேற்கிறோம். அரசு திட்டங்களைப் பெற பதிவு செய்யுங்கள்.'
    ctaText = lang === 'en' ? 'Register' : 'பதிவு செய்க'
    Call sendFlowMessage(phone, imageUrl, bodyText, '', 
      process.env.WHATSAPP_REG_FLOW_ID || 'PENDING',
      ctaText, 'DETAILS', { phone })

  Default: ignore (do not reply to unknown messages in Phase 1)

### 5. Modify backend/server.js
Change the express.json line from:
  app.use(express.json({ limit: '8mb' }));
To:
  app.use(express.json({ 
    limit: '8mb', 
    verify: (req, res, buf) => { req.rawBody = buf; }
  }));

Add route mounts at the bottom (after existing routes):
  const whatsappWebhookRoutes = require('./routes/whatsappWebhook');
  app.use('/api/whatsapp', whatsappWebhookRoutes);

## npm packages to install
Run in backend/:
  npm install node-forge sharp

(axios is already present)

## Constraints
- Never log META_APP_SECRET or META_ACCESS_TOKEN values
- HMAC verification must use req.rawBody (the raw bytes before JSON parsing)
- Always return 200 to Meta webhook immediately — process async if needed
- metaCloud functions: catch all errors, log with prefix [metaCloud], return null

## Output — write to handoffs/phase_1_handoff.md

Create `whatsapp_prompts/handoffs/phase_1_handoff.md`:

```
# Phase 1 Handoff — Infrastructure

## Files Created
- [list with relative paths from project root]

## Files Modified
- [list with what changed]

## npm Packages Added
- [list]

## Verification
WhatsAppContact model created: [yes/no]
metaCloud.js functions built: sendText, sendInteractiveButtons, sendFlowMessage, downloadMedia [yes/no each]
Webhook GET verify route: [yes/no]
Webhook POST HMAC check: [yes/no]
rawBody capture in server.js: [yes/no]
Routes mounted in server.js: [yes/no]
"hi → language buttons" logic: [yes/no]
"language pick → Register CTA" logic: [yes/no]
node-forge installed: [yes/no]
sharp installed: [yes/no]

## Notes
[Anything Phase 2 should be aware of]

## Blockers for Phase 2
[list / none]

## Status
[READY FOR PHASE 2 / BLOCKED — reason]
```

Then update `whatsapp_prompts/progress.md` — Phase 1 status to ✅ Complete or ❌ Blocked.
