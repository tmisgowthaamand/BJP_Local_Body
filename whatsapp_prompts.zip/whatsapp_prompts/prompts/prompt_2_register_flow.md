# Phase 2 — Register Flow

## Read previous handoff first
Before starting, read `whatsapp_prompts/handoffs/phase_1_handoff.md`.
If Phase 1 status is BLOCKED, do not proceed — report the blocker.

## Project
BJP Nalam Thittam WhatsApp Automation — building on Phase 1 infra.
Backend working dir: `production bjp repo/backend/`
Phase 1 built: WhatsAppContact model, metaCloud service, webhook route, chatbot stub.

## Deliverable
Full registration journey inside WhatsApp Flow:
Screen 1 DETAILS (EPIC input) → Screen 2 CONFIRM (voter table) → 
Screen 3 SCHEMES (multi-select) → Screen 4 SUMMARY (confirmation) → 
member created + scheme applications saved → "Choose Service" CTA sent.

## Files to create

### 1. backend/services/imageBase64.js
fetchAsBase64(url, maxBytes = 240000):
  - If url is empty/null: return null
  - Fetch image buffer from url using axios (with responseType: 'arraybuffer')
  - Use sharp to resize: if width > 1600, resize to width 1600 maintaining aspect ratio
  - Convert to jpeg, quality 85
  - If buffer still > maxBytes, reduce quality by 10 iteratively until < maxBytes or quality < 20
  - Return base64 string (no data: URI prefix — just the raw base64)
  - Cache results in a Map with 10-minute TTL: key = url
  - Export bustCache(url) function: delete url from cache map

### 2. backend/services/waFlowJson.js
Export functions that return screen definition objects for the flow endpoint.
All text labels come from a labels object passed in (language-aware).

getLabels(lang):
  Return object with all label strings in the given language ('en' or 'ta').
  English labels:
    continue: 'Continue', confirm: 'Confirm', back: 'Back',
    epic_label: 'EPIC Number', phone_label: 'WhatsApp Number',
    voter_name: 'Name', district: 'District', assembly: 'Assembly',
    booth: 'Booth', gender: 'Gender', schemes_title: 'Select Schemes',
    summary_title: 'Registration Summary', confirm_title: 'Confirm Details'
  Tamil labels (translate all above to Tamil)

getDetailsScreen(phone, lang):
  Returns DETAILS screen object:
  {
    screen: 'DETAILS',
    data: {
      labels: getLabels(lang),
      phone_prefilled: phone
    },
    layout: {
      type: 'SingleColumnLayout',
      children: [
        { type:'TextInput', name:'phone_display', label: labels.phone_label, 
          input_type:'phone', default_value: phone, enabled: false },
        { type:'TextInput', name:'epic_no', label: labels.epic_label, 
          input_type:'text', required: true },
        { type:'Footer', label: labels.continue, on_click_action: {
          type:'data_exchange', payload:{ screen:'DETAILS' }
        }}
      ]
    }
  }

getConfirmScreen(voterData, lang):
  voterData = { name, district, assembly, booth, gender }
  Returns CONFIRM screen showing voter details as text body rows + Continue footer

getSchemesScreen(schemes, lang):
  schemes = array of { id, name, name_ta, benefit, benefit_ta, waLogo (base64 or null) }
  Returns SCHEMES screen with CheckboxGroup (multi-select, min 1 required)
  Each item: { id: String(scheme.id), title: lang==='ta' ? scheme.name_ta || scheme.name : scheme.name,
    description: lang==='ta' ? scheme.benefit_ta || scheme.benefit : scheme.benefit }

getSummaryScreen(selectedSchemeNames, lang):
  Returns SUMMARY screen listing selected scheme names as text body + Confirm footer

### 3. backend/routes/whatsappFlow.js
POST /api/whatsapp/flow

Decryption (using node-forge):
  1. Parse request body as JSON: { encrypted_flow_data, encrypted_aes_key, initial_vector }
  2. Decrypt encrypted_aes_key with RSA private key (FLOW_PRIVATE_KEY from env, RSA-OAEP SHA-256)
  3. Decrypt encrypted_flow_data with AES-128-GCM using decrypted AES key + initial_vector
  4. Parse decrypted bytes as JSON: { version, action, screen, data, flow_token }

Route by action:
  'ping': re-encrypt and return { data: { status: 'active' } }
  
  'INIT' (screen === 'DETAILS'):
    Get WhatsAppContact by flow_token (phone)
    Return getDetailsScreen(phone, contact.language) — re-encrypted
  
  'data_exchange' (screen === 'DETAILS'):
    Extract epic_no from data
    Call findVoterByEpic(epic_no) → get voter doc
    If not found: return error screen { error_message: 'EPIC not found. Check your voter ID.' }
    Save voter snapshot to WhatsAppContact.lastVoterSnapshot
    Return getConfirmScreen(voterData, contact.language) — re-encrypted
  
  'data_exchange' (screen === 'CONFIRM'):
    Fetch active schemes from DB: Scheme.find({ active: true }).sort({ order: 1, id: 1 })
    For each scheme with waLogo: fetchAsBase64(scheme.waLogo) (from imageBase64.js)
    Return getSchemesScreen(schemes, contact.language) — re-encrypted
  
  'data_exchange' (screen === 'SCHEMES'):
    Extract selected scheme ids from data (array of String ids)
    Fetch scheme names for selected ids
    Return getSummaryScreen(selectedSchemeNames, contact.language) — re-encrypted
  
  'data_exchange' (screen === 'SUMMARY') — this is the CONFIRM action:
    Extract epic_no, selected scheme ids, voter snapshot from WhatsAppContact
    Call handleFlowComplete(phone, 'REGISTER', { epicNo, selectedSchemeIds, voterData })
    Return { screen: 'SUCCESS', data: {} } — re-encrypted (closes the flow)

  'BACK': return previous screen based on current screen name

Re-encryption:
  Generate new random 16-byte IV
  Encrypt response JSON with same AES key (from decryption step) + new IV using AES-128-GCM
  Return: { encrypted_flow_data: base64, encrypted_aes_key: base64(same key), initial_vector: base64(new IV) }

Mount in server.js:
  const whatsappFlowRoutes = require('./routes/whatsappFlow');
  app.use('/api/whatsapp', whatsappFlowRoutes);

### 4. Extend backend/services/whatsappChatbot.js
Add handleFlowComplete(phone, flowType, payload):

  If flowType === 'REGISTER':
    const { epicNo, selectedSchemeIds, voterData } = payload
    const contact = await WhatsAppContact.findOne({ phone })
    const lang = contact?.language || 'en'

    // Check if user already exists
    let user = await User.findOne({ mobile: phone })
    
    if (!user) {
      const ntCode = 'NT-' + Math.random().toString(36).substring(2,10).toUpperCase()
      user = await User.create({
        mobile: phone,
        epicNo: epicNo,
        voterName: voterData.name,
        district: voterData.district,
        assemblyName: voterData.assembly,
        boothNo: voterData.booth,
        gender: voterData.gender || 'Unspecified',
        referralCode: ntCode,
        referredBy: null
      })
    }

    // Create scheme applications (skip duplicates)
    const schemes = await Scheme.find({ id: { $in: selectedSchemeIds.map(Number) }, active: true })
    for (const scheme of schemes) {
      const exists = await SchemeApplication.findOne({ userId: user._id, schemeId: scheme.id })
      if (!exists) {
        await SchemeApplication.create({
          userId: user._id,
          voterName: user.voterName,
          epicNo: user.epicNo,
          mobile: user.mobile,
          district: user.district,
          assemblyName: user.assemblyName,
          boothNo: user.boothNo,
          schemeId: scheme.id,
          schemeName: scheme.name,
          clusterName: scheme.cluster || 'BJP Nalam Thittam',
          benefit: scheme.benefit || '',
          status: 'Submitted',
          appliedAt: new Date()
        })
      }
    }

    // Update contact state
    await WhatsAppContact.findOneAndUpdate({ phone }, { step: 'SERVICE_CTA' })

    // Send "Choose Service" CTA
    const serviceImageUrl = '' // placeholder — Phase 5 wires real image
    const bodyText = lang === 'en' 
      ? 'Registration complete! Access your services below.'
      : 'பதிவு முடிந்தது! உங்கள் சேவைகளை கீழே அணுகவும்.'
    const ctaText = lang === 'en' ? 'Choose Service' : 'சேவை தேர்வு'
    await sendFlowMessage(phone, serviceImageUrl, bodyText, '',
      process.env.WHATSAPP_SERVICE_FLOW_ID || 'PENDING',
      ctaText, 'MENU', { phone })

### 5. Modify backend/models/Scheme.js
Add two fields inside the schema (after imagePublicId):
  waLogo: { type: String, default: '' },
  waBanner: { type: String, default: '' }

## Constraints
- RSA private key in FLOW_PRIVATE_KEY env may be single-line (newlines as \n) or multiline — handle both
- voterData in WhatsAppContact.lastVoterSnapshot is session-only, not exposed in any API
- Scheme multi-select: minimum 1 must be selected (enforce in screen definition required:true)
- Do not send the "Choose Service" CTA until registration + all scheme applications are saved
- All imports: require() style (CommonJS) — this is not an ES module project

## Output — write to handoffs/phase_2_handoff.md

Create `whatsapp_prompts/handoffs/phase_2_handoff.md`:

```
# Phase 2 Handoff — Register Flow

## Files Created
- [list]

## Files Modified
- [list]

## Verification
imageBase64.js (fetch + resize + cache + bustCache): [yes/no]
waFlowJson.js (getDetailsScreen, getConfirmScreen, getSchemesScreen, getSummaryScreen): [yes/no]
whatsappFlow.js route (RSA decrypt + AES re-encrypt): [yes/no]
Flow screens built: DETAILS [y/n], CONFIRM [y/n], SCHEMES [y/n], SUMMARY [y/n]
BACK action handled: [yes/no]
handleFlowComplete REGISTER: [yes/no]
User creation on registration: [yes/no]
SchemeApplication creation (multi-select): [yes/no]
Duplicate scheme application check: [yes/no]
"Choose Service" CTA sent after register: [yes/no]
Scheme model waLogo/waBanner fields added: [yes/no]
Flow route mounted in server.js: [yes/no]

## Notes
[Anything Phase 3 should know]

## Blockers for Phase 3
[list / none]

## Status
[READY FOR PHASE 3 / BLOCKED — reason]
```

Then update `whatsapp_prompts/progress.md` — Phase 2 status.
