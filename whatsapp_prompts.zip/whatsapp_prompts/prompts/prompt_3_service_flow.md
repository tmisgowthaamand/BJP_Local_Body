# Phase 3 — Service Flow

## Read previous handoff first
Before starting, read `whatsapp_prompts/handoffs/phase_2_handoff.md`.
If Phase 2 status is BLOCKED, do not proceed — report the blocker.

## Project
BJP Nalam Thittam WhatsApp Automation — building on Phase 1 + 2.
Backend working dir: `production bjp repo/backend/`
Phase 2 built: full register flow, imageBase64, waFlowJson (register screens),
handleFlowComplete(REGISTER) in whatsappChatbot.js.

## Deliverable
"Choose Service" flow with 5 service tiles:
My Profile → member details table
My Schemes → applied schemes list → status screen
Apply Schemes → not-yet-applied schemes (multi-select) → confirm → applications created
My Referral Link → referral link + count
My Members → referred members list (no EPIC shown)
Each service routes back to the service menu after completion.

## Files to create/extend

### 1. backend/services/waServiceCatalog.js
Export SERVICE_TILES array (Booth President added in Phase 4):
[
  {
    id: 'my_profile',
    title_en: 'My Profile', title_ta: 'என் சுயவிவரம்',
    desc_en: 'View your member details', desc_ta: 'உங்கள் விவரங்களைக் காண்க',
    icon_key: 'wa_svc_my_profile'
  },
  {
    id: 'my_schemes',
    title_en: 'My Schemes', title_ta: 'என் திட்டங்கள்',
    desc_en: 'View applied schemes and status', desc_ta: 'விண்ணப்பித்த திட்டங்கள் நிலை',
    icon_key: 'wa_svc_my_schemes'
  },
  {
    id: 'apply_schemes',
    title_en: 'Apply Schemes', title_ta: 'திட்டம் விண்ணப்பிக்க',
    desc_en: 'Apply for new welfare schemes', desc_ta: 'புதிய திட்டங்களுக்கு விண்ணப்பிக்க',
    icon_key: 'wa_svc_apply_schemes'
  },
  {
    id: 'my_referral',
    title_en: 'My Referral Link', title_ta: 'என் பரிந்துரை இணைப்பு',
    desc_en: 'Share your referral link', desc_ta: 'பரிந்துரை இணைப்பை பகிரவும்',
    icon_key: 'wa_svc_referral'
  },
  {
    id: 'my_members',
    title_en: 'My Members', title_ta: 'என் உறுப்பினர்கள்',
    desc_en: 'Members you have referred', desc_ta: 'நீங்கள் பரிந்துரைத்தவர்கள்',
    icon_key: 'wa_svc_members'
  }
]

### 2. Extend backend/services/waFlowJson.js (add Service flow screens)
Add these screen builder functions (all accept lang parameter):

getServiceMenuScreen(tiles, lang):
  tiles = SERVICE_TILES with icon base64 injected
  Returns MENU screen with RadioButtonsGroup or ListPicker of 5 tiles
  Each item: id, title (lang-aware), description (lang-aware), optional image (base64)
  Footer: label = lang==='en' ? 'Select' : 'தேர்ந்தெடு'

getMyProfileScreen(user, lang):
  user = User document
  Returns MY_PROFILE screen as TextBody rows:
    Name: user.voterName
    EPIC: user.epicNo
    District: user.district
    Assembly: user.assemblyName
    Booth: user.boothNo
    Member Since: user.createdAt formatted as DD/MM/YYYY
  Footer: Back to menu

getMySchemesList(applications, lang):
  applications = array of SchemeApplication
  Returns MY_SCHEMES screen as a list (RadioButtonsGroup) so user can tap one
  Each item: schemeName + status badge text
  Footer: Back to menu

getSchemeStatusScreen(application, lang):
  Returns SCHEME_STATUS screen:
    Scheme: application.schemeName
    Applied: application.appliedAt formatted
    Status: application.status
  Footer: Back

getApplySchemesScreen(availableSchemes, lang):
  availableSchemes = schemes not yet applied by user
  Returns APPLY_SCHEMES screen as CheckboxGroup (multi-select, min 1)
  Same structure as Register SCHEMES screen
  Footer: Apply

getApplyConfirmScreen(selectedSchemeNames, lang):
  Returns APPLY_CONFIRM screen listing selected schemes
  Footer: Confirm + Back

getMyReferralScreen(user, referralCount, lang):
  Returns MY_REFERRAL screen:
    Your referral link: https://tnbjp.org/r/{user.referralCode}
    Members referred: {referralCount}
  Footer: Back to menu

getMyMembersScreen(members, lang):
  members = array of { voterName, district } — NO epicNo, NO mobile (DPDP)
  Returns MY_MEMBERS screen as list of member names + district
  Default icon: wa_member_default_icon base64 for each entry
  Footer: Back to menu

### 3. Extend backend/routes/whatsappFlow.js
Add data_exchange handlers for service flow screens:

screen === 'MENU' (INIT or data_exchange):
  Lookup User by phone
  If user not found: return error asking them to register first
  Load SERVICE_TILES from waServiceCatalog
  For each tile: fetchAsBase64(FlowImage url for tile.icon_key) if available
  Return getServiceMenuScreen(tiles, lang)

screen === 'MENU' (data_exchange, service selected):
  Extract selected service id from data
  Route to appropriate screen handler below

screen === 'MY_PROFILE':
  User = await User.findOne({ mobile: phone })
  Return getMyProfileScreen(user, lang)

screen === 'MY_SCHEMES':
  applications = await SchemeApplication.find({ userId: user._id }).sort({ appliedAt: -1 })
  Return getMySchemesList(applications, lang)

screen === 'SCHEME_STATUS':
  applicationId from data
  application = await SchemeApplication.findById(applicationId)
  Return getSchemeStatusScreen(application, lang)

screen === 'APPLY_SCHEMES':
  allSchemes = await Scheme.find({ active: true }).sort({ order: 1, id: 1 })
  appliedIds = (await SchemeApplication.find({ userId: user._id })).map(a => a.schemeId)
  availableSchemes = allSchemes.filter(s => !appliedIds.includes(s.id))
  Return getApplySchemesScreen(availableSchemes, lang)

screen === 'APPLY_CONFIRM':
  selectedSchemeIds from data
  Fetch scheme names
  Return getApplyConfirmScreen(selectedSchemeNames, lang)

screen === 'APPLY_CONFIRM' (Confirm action):
  Call handleFlowComplete(phone, 'APPLY_SCHEMES', { selectedSchemeIds })
  Return { screen:'SUCCESS', data:{} } — closes flow
  (whatsappChatbot then re-sends Choose Service CTA)

screen === 'MY_REFERRAL':
  referralCount = await User.countDocuments({ referredBy: user.referralCode })
  Return getMyReferralScreen(user, referralCount, lang)

screen === 'MY_MEMBERS':
  members = await User.find({ referredBy: user.referralCode })
    .select('voterName district') — explicitly exclude epicNo and mobile
  defaultIcon = await fetchAsBase64(FlowImage url for 'wa_member_default_icon')
  Return getMyMembersScreen(members, lang)

screen === 'BACK':
  Return getServiceMenuScreen with current tiles (loop back to menu)

### 4. Extend backend/services/whatsappChatbot.js
Add handleFlowComplete for flowType === 'APPLY_SCHEMES':
  const { selectedSchemeIds } = payload
  const user = await User.findOne({ mobile: phone })
  const schemes = await Scheme.find({ id: { $in: selectedSchemeIds.map(Number) }, active: true })
  for (const scheme of schemes) {
    const exists = await SchemeApplication.findOne({ userId: user._id, schemeId: scheme.id })
    if (!exists) {
      await SchemeApplication.create({ ...same fields as Phase 2 register... })
    }
  }
  // Re-send Choose Service CTA
  const contact = await WhatsAppContact.findOne({ phone })
  const lang = contact?.language || 'en'
  await sendFlowMessage(phone, '', 
    lang==='en' ? 'Schemes applied!' : 'திட்டங்கள் விண்ணப்பிக்கப்பட்டன!',
    '', process.env.WHATSAPP_SERVICE_FLOW_ID || 'PENDING',
    lang==='en' ? 'Choose Service' : 'சேவை தேர்வு',
    'MENU', { phone })

Also add: already-registered user sends "hi" flow
In handleInbound, Case 1 (hi/hello):
  Check if User.findOne({ mobile: phone }) exists
  If EXISTS: skip register CTA, go directly to service CTA (update step to SERVICE_CTA)
  If NOT: proceed with language buttons as before

## Constraints
- MY_MEMBERS and MY_REFERRAL screens must NOT expose epicNo or mobile (DPDP Act)
- My Schemes query: filter by userId only, never by epicNo (prevents cross-user leak)
- Apply Schemes: show only schemes where NO SchemeApplication exists for this userId
- All screen label text is language-aware — use lang parameter throughout
- Returning to menu after any service: always re-send MENU screen via flow or re-send
  "Choose Service" CTA message depending on flow completion type

## Output — write to handoffs/phase_3_handoff.md

Create `whatsapp_prompts/handoffs/phase_3_handoff.md`:

```
# Phase 3 Handoff — Service Flow

## Files Created
- [list]

## Files Modified
- [list]

## Verification
waServiceCatalog.js (5 tiles): [yes/no]
MENU screen: [yes/no]
MY_PROFILE screen: [yes/no]
MY_SCHEMES + SCHEME_STATUS screens: [yes/no]
APPLY_SCHEMES (multi-select) + APPLY_CONFIRM: [yes/no]
MY_REFERRAL screen (no mobile/EPIC): [yes/no]
MY_MEMBERS screen (no EPIC/mobile): [yes/no]
handleFlowComplete APPLY_SCHEMES: [yes/no]
Re-send service CTA after apply: [yes/no]
Already-registered user "hi" → direct service CTA: [yes/no]
BACK → menu loop: [yes/no]

## Notes
[Anything Phase 4 should know]

## Blockers for Phase 4
[list / none]

## Status
[READY FOR PHASE 4 / BLOCKED — reason]
```

Then update `whatsapp_prompts/progress.md` — Phase 3 status.
