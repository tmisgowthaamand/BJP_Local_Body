# Phase 6 — Meta Wiring & QA

## Read previous handoff first
Before starting, read `whatsapp_prompts/handoffs/phase_5_handoff.md`.
If Phase 5 status is BLOCKED, do not proceed — report the blocker.

## Project
BJP Nalam Thittam WhatsApp Automation — final phase.
Backend working dir: `production bjp repo/backend/`
All flow logic, service flow, booth president, admin images panel are complete.
Now: generate RSA keys, create real Meta flows, upload flow JSON, set endpoints, publish, QA.

## Deliverable
WhatsApp automation is LIVE on the production number.
All QA checks pass. All env vars populated.

## Part 1 — Build Setup Script

### backend/scripts/setupWhatsappFlows.js
One-time setup script — run once on the server: node scripts/setupWhatsappFlows.js
Must be idempotent: skip steps if already done (check .env values first).

Load dotenv at the top. Use axios for all Meta API calls.
BASE = https://graph.facebook.com/v22.0
TOKEN = process.env.META_ACCESS_TOKEN
PHONE_ID = process.env.META_PHONE_NUMBER_ID
WABA_ID = process.env.META_WABA_ID

STEP 1 — RSA Key Generation
  If FLOW_PRIVATE_KEY is already set in .env and non-empty: skip this step, log "RSA keys already exist"
  Else:
    Use node-forge: generate 2048-bit RSA key pair
    privateKeyPem = forge.pki.privateKeyToPem(keypair.privateKey)
    publicKeyPem = forge.pki.publicKeyToPem(keypair.publicKey)
    Write both to .env:
      FLOW_PRIVATE_KEY=<privateKeyPem with \n escaped as \\n>
      FLOW_PUBLIC_KEY=<publicKeyPem with \n escaped as \\n>
    Log: "RSA keys generated and written to .env"

STEP 2 — Upload public key to Meta phone number
  POST {BASE}/{PHONE_ID}/whatsapp_business_encryption
  body: { business_public_key: publicKeyPem }
  headers: { Authorization: 'Bearer ' + TOKEN }
  On success: log "Public key uploaded to Meta"
  On failure: log error + EXIT (stop script)

STEP 3 — Create Register flow
  If WHATSAPP_REG_FLOW_ID is set in .env and non-empty: 
    log "Register flow already exists: " + id, skip
  Else:
    POST {BASE}/{WABA_ID}/flows
    body: { name: 'BJP Nalam Register', categories: ['REGISTRATION'] }
    regFlowId = response.data.id
    Append to .env: WHATSAPP_REG_FLOW_ID={regFlowId}
    Log "Register flow created: " + regFlowId

STEP 4 — Create Service flow
  If WHATSAPP_SERVICE_FLOW_ID set: skip
  Else:
    POST {BASE}/{WABA_ID}/flows
    body: { name: 'BJP Nalam Service', categories: ['CUSTOMER_SUPPORT'] }
    svcFlowId = response.data.id
    Append to .env: WHATSAPP_SERVICE_FLOW_ID={svcFlowId}
    Log "Service flow created: " + svcFlowId

STEP 5 — Export and upload flow JSON assets
  require waFlowJson.js — call getRegisterFlowJson() and getServiceFlowJson()
  (You need to add these two export functions to waFlowJson.js:
    getRegisterFlowJson(): returns the full Meta Flows JSON object for the register flow
      with all 4 screens: DETAILS, CONFIRM, SCHEMES, SUMMARY
      Use ${data.xxx} placeholders for dynamic content
    getServiceFlowJson(): returns the full Meta Flows JSON object for the service flow
      with all screens: MENU, MY_PROFILE, MY_SCHEMES, SCHEME_STATUS, APPLY_SCHEMES, 
      APPLY_CONFIRM, MY_REFERRAL, MY_MEMBERS, BOOTH_PRESIDENT, BOOTH_STATUS, 
      BOOTH_CURRENT, BOOTH_DISTRICT, BOOTH_ASSEMBLY, BOOTH_BOOTH, BOOTH_CONFIRM
  )
  
  For Register flow:
    POST {BASE}/{regFlowId}/assets (multipart/form-data)
    file field: Buffer of JSON.stringify(registerFlowJson), filename: 'flow.json', 
    content_type: 'application/json'
    Log "Register flow JSON uploaded"
  
  For Service flow: same

STEP 6 — Set flow endpoint URL on both flows
  ENDPOINT_URL = https://tnbjp.org/api/whatsapp/flow
  For each flowId in [regFlowId, svcFlowId]:
    POST {BASE}/{flowId}/whatsapp_flows_endpoint_url
    body: { endpoint_url: ENDPOINT_URL }
    Log "Endpoint set on flow " + flowId

STEP 7 — Publish both flows
  For each flowId:
    POST {BASE}/{flowId}/publish
    Log "Flow published: " + flowId

STEP 8 — Final summary
  Log:
    "=== SETUP COMPLETE ==="
    "Register Flow ID: " + regFlowId
    "Service Flow ID: " + svcFlowId
    "Flow Endpoint: " + ENDPOINT_URL
    ""
    "MANUAL STEP REQUIRED:"
    "Go to Meta App Dashboard → WhatsApp → Configuration → Webhook"
    "Callback URL: https://tnbjp.org/api/whatsapp/webhook"
    "Verify Token: bjp_nalam_whatsapp_2026"
    "Subscribe to: messages"

Script must:
- Never log META_APP_SECRET or META_ACCESS_TOKEN values
- Stop immediately on any API error (log the error body + status code)
- Work idempotently: re-running it won't duplicate flows or overwrite existing RSA keys

## Part 2 — Add getRegisterFlowJson() and getServiceFlowJson() to waFlowJson.js
These functions return the static Meta Flows JSON structure (not runtime screen objects).
The structure follows Meta Flows JSON schema (version "5.0" or current).
All dynamic text uses ${data.xxx} variable references.
Each screen has a routing_model and layout with the components defined in Phases 2–4.

Example structure:
{
  "version": "5.0",
  "screens": [
    {
      "id": "DETAILS",
      "title": "${data.labels.details_title}",
      "terminal": false,
      "layout": { "type": "SingleColumnLayout", "children": [...] }
    },
    ...
  ]
}

## Part 3 — QA Checklist
Run each check manually (on real WhatsApp with test number) and record result.
Do NOT mark as pass if not actually tested.

| # | Test | Expected | Result |
|---|------|----------|--------|
| 1 | Send "hi" to the number | Language buttons (English / தமிழ்) | |
| 2 | Tap "English" | Register CTA message | |
| 3 | Open Register flow → enter EPIC → continue | Voter confirm screen with name/district/assembly/booth | |
| 4 | Confirm voter → continue | Schemes multi-select screen | |
| 5 | Select 2+ schemes → continue → confirm | "Registration complete" + Choose Service CTA | |
| 6 | Open Choose Service → My Profile | Member details (no EPIC on mobile, EPIC shown is ok here actually — it's their own data) | |
| 7 | My Schemes | Both applied schemes listed with status | |
| 8 | Apply Schemes | Only schemes NOT yet applied shown | |
| 9 | Apply 1 new scheme → confirm | "Schemes applied!" + Choose Service CTA | |
| 10 | My Referral Link | Referral link + count shown, no mobile/EPIC | |
| 11 | My Members | Members list, no EPIC, no mobile | |
| 12 | Be a Booth President → confirm own booth | BoothPresidentRequest created, status: Pending | |
| 13 | Be a Booth President again (already submitted) | Status screen shows Pending | |
| 14 | New number → "hi" → Tamil → Register | All screens in Tamil | |
| 15 | Already-registered number sends "hi" | Goes directly to Choose Service CTA (skips register) | |
| 16 | Open Another Booth flow → pick district → assembly loads | Assemblies filtered for that district | |
| 17 | Pick assembly → booth loads | Booths for that assembly | |

## Output — write to handoffs/phase_6_handoff.md

Create `whatsapp_prompts/handoffs/phase_6_handoff.md`:

```
# Phase 6 Handoff — Meta Wiring & QA

## Setup Script Results
RSA keys generated: [yes/skipped-existing]
Public key uploaded to Meta: [yes/no]
Register flow created: [yes/skipped] — ID: [id]
Service flow created: [yes/skipped] — ID: [id]
Register flow JSON uploaded: [yes/no]
Service flow JSON uploaded: [yes/no]
Endpoint set on both flows: [yes/no]
Both flows published: [yes/no]

## Env Vars Now Set
FLOW_PRIVATE_KEY: [set/missing]
FLOW_PUBLIC_KEY: [set/missing]
WHATSAPP_REG_FLOW_ID: [value/missing]
WHATSAPP_SERVICE_FLOW_ID: [value/missing]

## Webhook Config (manual step)
Webhook configured in Meta App Dashboard: [done/pending]

## QA Results
| # | Test | Result |
|---|------|--------|
| 1 | hi → language buttons | pass/fail |
| 2 | English → Register CTA | pass/fail |
| 3 | EPIC → voter confirm | pass/fail |
| 4 | Confirm → schemes | pass/fail |
| 5 | Multi-select + confirm → service CTA | pass/fail |
| 6 | My Profile | pass/fail |
| 7 | My Schemes | pass/fail |
| 8 | Apply Schemes (not yet applied only) | pass/fail |
| 9 | Apply + confirm → service CTA | pass/fail |
| 10 | My Referral Link | pass/fail |
| 11 | My Members (no EPIC/mobile) | pass/fail |
| 12 | Booth President — own booth | pass/fail |
| 13 | Booth President — duplicate blocked | pass/fail |
| 14 | Tamil full flow | pass/fail |
| 15 | Registered user → direct service CTA | pass/fail |
| 16 | Another Booth district → assembly | pass/fail |
| 17 | Assembly → booths | pass/fail |

## Known Issues
[list / none]

## Final System Status
[LIVE — all QA passed / PARTIAL — issues listed above / NOT LIVE — blocked]
```

Then update `whatsapp_prompts/progress.md` — Phase 6 status and Current phase = "Complete".
