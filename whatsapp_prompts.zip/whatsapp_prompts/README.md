# BJP Nalam Thittam — WhatsApp Automation Build

## Instructions for Antigravity

You are executing a 7-phase WhatsApp automation build for BJP Nalam Thittam.
Run phases in strict ascending order: Phase 0 → Phase 1 → ... → Phase 6.

### Rules
1. Read `prompts/prompt_N_*.md` for the phase instructions.
2. Before Phase 1 onwards, read `handoffs/phase_{N-1}_handoff.md` for context from the previous phase.
3. Execute the task described in the prompt completely.
4. After completing each phase, write your completion summary to `handoffs/phase_N_handoff.md`.
5. Update `progress.md` — change the phase status from ⬜ Pending to ✅ Complete (or ❌ Blocked if something failed).
6. Do NOT start the next phase until the current handoff file is written and progress.md is updated.
7. If a phase is blocked, write the blocker clearly in the handoff file and STOP. Do not proceed to the next phase.

### Project Context
- Project: BJP Nalam Thittam WhatsApp Automation
- Backend working dir: `production bjp repo/backend/`
- Frontend working dir: `production bjp repo/frontend/src/`
- Stack: Node.js + Express + MongoDB (Mongoose) + React + Vite
- Meta Graph API version: v22.0
- Live domain: https://tnbjp.org
- Reference plan: `WHATSAPP_AUTOMATION_PLAN.md` (in project root Downloads)

### Phase Order
| File | Phase | Description |
|------|-------|-------------|
| prompts/prompt_0_verify.md | 0 | Verify Meta credentials & environment |
| prompts/prompt_1_infra.md | 1 | Infrastructure (webhook, metaCloud, WhatsAppContact model) |
| prompts/prompt_2_register_flow.md | 2 | Register Flow (screens, EPIC lookup, member creation) |
| prompts/prompt_3_service_flow.md | 3 | Service Flow (My Profile, Schemes, Referral, Members) |
| prompts/prompt_4_booth_president.md | 4 | Booth President (cascading dropdowns + status) |
| prompts/prompt_5_admin_images.md | 5 | Admin Flow Images Page (Super Admin panel) |
| prompts/prompt_6_meta_wiring.md | 6 | Meta Wiring + QA (create flows, publish, test) |

Start with `prompts/prompt_0_verify.md`.
